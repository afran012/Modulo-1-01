const API_DETAILS = {
    API_URL : 'https://api.giphy.com/v1',
    API_KEY : 'VGMet3jkVt6odgACtHxZOolIHWxqwLZs'
}

let NOCTURNE_MODE = {
    NOCTURNE:false
}

let CREATE_GIF = {
    api_key:'VGMet3jkVt6odgACtHxZOolIHWxqwLZs' ,
    username:'afran012' ,
    tags:'Acamica'
}

let SEARCH_SECTION = {
    inputSearchValue : "",
    limitSearch : 12,
    offsetSearch : 0,
    limitAutocomplete : 4,
    offsetAutocomplete : 0,
    currentSearch : 0
}

let GIFMAX = {
    gifMax : [],
    pathPage : "../"
}

let CREATEGIF = {
    action : "openVideo"
}

export {API_DETAILS , NOCTURNE_MODE , CREATE_GIF, SEARCH_SECTION , GIFMAX , CREATEGIF } 