# GIFOS
In this repository the design of a gifos web page is stored, made with html, css, and js.
