const CONFIG_DEV = {
    URL_GYPHI: 'htttp://SERVER',
    APY_KEY: 'grdhftjygkhujk'
};

export { CONFIG_DEV };