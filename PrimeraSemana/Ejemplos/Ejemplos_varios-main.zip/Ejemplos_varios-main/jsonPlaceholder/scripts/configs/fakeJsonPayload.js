export default {
  token: "WyFA9XzG7yoQsPXvAfrxfQ",
  data: {
    first_name: "nameFirst",
    last_name: "nameLast",
    location: {
      street: "addressStreetName",
      city: "addressCity",
      state: "addressState",
      country: "addressCountry",
    },
    contacts: {
      email: "internetEmail",
      mobile: "phoneMobile",
    },
    job: {
      company: "companyName",
      department: "companyDepartment",
      position: "personTitle",
      phone_numbers: "functionArray|3|phoneHome",
    },
    numberInt: "numberInt",
    numberFloat: "numberFloat",
    numberBool: "numberBool",
    _repeat: 20,
  },
};
