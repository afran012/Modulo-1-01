const CONFIG_DEV = {
    USER_SERVICE_URL: 'https://jsonplaceholder.typicode.com',
    FAKE_JSON_URL: 'https://app.fakejson.com/q'
};

const CONFIG_QA = {
    USER_SERVICE_URL: 'https://jsonplaceholder.typicode.com'
};

const CONFIG_PROD = {
    USER_SERVICE_URL: 'https://jsonplaceholder.typicode.com'
};

export { CONFIG_DEV, CONFIG_QA, CONFIG_PROD };