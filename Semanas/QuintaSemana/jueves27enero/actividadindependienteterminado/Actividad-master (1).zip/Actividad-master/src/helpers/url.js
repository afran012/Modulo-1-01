

export const url = 'http://localhost:4000/productos/';