
export const types = {
    login: 'login',
    logout: 'logout',
    registro: 'registro'
}

export const typesEmpleoyees = {
    register: 'Register',
    list: 'List',
    delete: 'Delete'
}