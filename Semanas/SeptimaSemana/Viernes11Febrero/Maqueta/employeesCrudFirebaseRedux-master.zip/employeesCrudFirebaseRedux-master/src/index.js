import React from 'react';
import ReactDOM from 'react-dom';
import {EmployeesApp} from './EmployeesApp';;

ReactDOM.render(
 <EmployeesApp/>,
  document.getElementById('root')
);

