import React from 'react';
import {AppRouter} from './routers/AppRouter';

export const EmployeesApp = () => {
    return (
        <div>
            <AppRouter/>
        </div>
    )
}
