

export const typesEmpleoyees = {

    register: 'Register',
    list: 'List',
    delete: 'Delete'
}