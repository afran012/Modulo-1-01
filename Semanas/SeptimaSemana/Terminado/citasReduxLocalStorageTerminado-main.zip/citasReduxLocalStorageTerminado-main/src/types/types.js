

export const types = {
    agregar: 'Agregar',
    borrar: 'Borrar'
}