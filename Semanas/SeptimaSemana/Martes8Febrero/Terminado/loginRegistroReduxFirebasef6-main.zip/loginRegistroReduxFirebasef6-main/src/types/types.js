
 export const types = {
     login: 'login',
     logout: 'logout',
     register: 'register'
 }

 