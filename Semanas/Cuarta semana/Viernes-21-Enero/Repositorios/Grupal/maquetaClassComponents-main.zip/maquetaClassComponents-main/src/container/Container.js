import React, { Component } from 'react';
import Formulario from '../components/Formulario';

export default class Container extends Component {
    render() {
        return (
            <>
                <Formulario/>
            </>
        );
    }
}
