
export const types = {
    increment: 'INCREMENT',
    decrement: 'DECREMENT',
    reset: 'RESET'
}