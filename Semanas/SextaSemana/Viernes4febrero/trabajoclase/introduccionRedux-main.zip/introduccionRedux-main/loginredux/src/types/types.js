
export const types = {
    login: 'Login',
    logout: 'Logout'
}