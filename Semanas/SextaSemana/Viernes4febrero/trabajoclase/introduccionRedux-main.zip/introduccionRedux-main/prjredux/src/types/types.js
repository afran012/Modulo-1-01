

export const types = {
    registro: 'Registro'
}