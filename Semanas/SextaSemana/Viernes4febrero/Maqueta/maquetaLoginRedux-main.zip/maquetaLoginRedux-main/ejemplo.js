export const ejemplo = {
  
   nombre: "Jenny"

}