import React from 'react'

const ListarProducto = () => {
    return (
        <div className="card mt-5">
        <div className="card-body">
            <h2 className="card-title text-center">Productos Almacenados</h2>
            <div className="lista-producto">
                <table className="table">
                    <thead>
                        <tr>
                            <th scope="col">Nombre Producto</th>
                        </tr>
                    </thead>
                    <tbody>
                       
                         
                    </tbody>
                </table>
            </div>
        </div >
    </div >
    )
}

export default ListarProducto;
