export const procesoPesado = (iteraciones) => {
    for (let i = 0; i < iteraciones; i++) {
        console.log("ahi vamos...");
    }
    return `${iteraciones} iteraciones realizadas`
}