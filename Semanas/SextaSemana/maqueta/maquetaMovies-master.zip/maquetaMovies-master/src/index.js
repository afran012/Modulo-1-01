import React from 'react';
import ReactDOM from 'react-dom';
import { MoviesApp } from './MoviesApp';



ReactDOM.render(
  <MoviesApp />,
  document.getElementById('root')
);
