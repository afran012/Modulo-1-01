export const types = {
    login: '[Auth] Login',
    logout: '[Auth] Logout',
    increment: '[Counter] increment Counter',
    decrement: '[Counter] decrement Counter',
    reset: '[Counter] reset Counter'
}